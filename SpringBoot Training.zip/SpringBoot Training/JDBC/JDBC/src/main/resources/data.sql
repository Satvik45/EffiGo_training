insert into alien(id,name,tech) values (101, 'Satvik', 'Blockchain');
insert into alien(id,name,tech) values (102, 'Aryan', 'AI');
insert into alien(id,name,tech) values (103, 'Abya', 'IOT');