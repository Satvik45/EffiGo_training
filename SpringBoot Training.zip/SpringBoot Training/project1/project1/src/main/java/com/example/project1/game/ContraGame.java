package com.example.project1.game;

public class ContraGame implements GamingConsole {

    public void up(){
        System.out.println("Super Up");
    }

    public void down(){
        System.out.println("Super down");
    }

    public void left(){
        System.out.println("Super left");
    }

    public void right(){
        System.out.println("Super right");
    }
} 
